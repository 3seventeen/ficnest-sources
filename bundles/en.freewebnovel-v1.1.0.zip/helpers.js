// Helper functions for FreeWebNovel source
// These functions are available globally in template.js

function extractBetween(text, start, end) {
    var startIndex = text.indexOf(start);
    if (startIndex === -1) return "";
    var textAfterStart = text.substring(startIndex + start.length);
    var endIndex = textAfterStart.indexOf(end);
    if (endIndex === -1) return textAfterStart;
    return textAfterStart.substring(0, endIndex);
}

function extractAll(text, pattern) {
    var results = [];
    var match;
    while ((match = pattern.exec(text)) !== null) {
        results.push(match);
    }
    return results;
}

function decodeHTML(text) {
    return text
        .replace(/&amp;/g, "&")
        .replace(/&lt;/g, "<")
        .replace(/&gt;/g, ">")
        .replace(/&quot;/g, '"')
        .replace(/&#39;/g, "'")
        .replace(/&nbsp;/g, " ");
}

function cleanContent(content) {
    content = content.replace(/<script[^>]*>[\s\S]*?<\/script>/gi, "");
    content = content.replace(/<style[^>]*>[\s\S]*?<\/style>/gi, "");
    return content;
}

function stripTags(text) {
    return text.replace(/<[^>]+>/g, "");
}

function normalizeWhitespace(text) {
    return text.replace(/\s{2,}/g, " ").trim();
}
