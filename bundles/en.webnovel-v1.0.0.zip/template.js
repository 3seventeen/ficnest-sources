// Webnovel source
// novelId format: "n__BOOKID" for originals, "f__BOOKID" for fanfics
// chapterId format: "NOVELID/CHAPTERID"

var baseUrl = SourceMetadata.baseURL;

// Parse novel cards from ranking/search pages (shared by getPopularNovels + searchNovels)
// novelType: "n" or "f"
function parseNovelSections(html, novelType) {
    var novels = [];
    var pos = 0;

    while (pos < html.length) {
        var secStart = html.indexOf('<section class="df g_hr pt16 pb16">', pos);
        if (secStart === -1) break;

        var secEnd = html.indexOf('</section>', secStart);
        if (secEnd === -1) break;

        var block = html.substring(secStart, secEnd);
        pos = secEnd + 1;

        // bookId from data-report-did on the thumbnail link
        var bookId = "";
        var didMatch = block.match(/class="g_thumb[^"]*"[^>]*data-report-did="([^"]+)"/);
        if (!didMatch) {
            didMatch = block.match(/data-report-did="([^"]+)"/);
        }
        if (didMatch) bookId = didMatch[1];
        if (!bookId) continue;

        // cover: prefer data-original (lazy load), fall back to src
        var coverUrl = "";
        var imgMatch = block.match(/data-original="([^"]+)"/);
        if (!imgMatch) imgMatch = block.match(/<img[^>]+src="([^"]+)"/);
        if (imgMatch) {
            coverUrl = imgMatch[1];
            if (coverUrl.indexOf("//") === 0) coverUrl = "https:" + coverUrl;
            // strip lazy gif placeholders
            if (coverUrl.indexOf("data:image") === 0) coverUrl = "";
        }
        // if cover was a GIF placeholder, try data-original again from img tag
        if (!coverUrl) {
            var imgOriginal = block.match(/<img[^>]+data-original="([^"]+)"/);
            if (imgOriginal) {
                coverUrl = "https:" + imgOriginal[1];
            }
        }

        // title from h3 > a
        var title = "";
        var titleMatch = block.match(/<h3[^>]*><a[^>]*title="([^"]+)"/);
        if (!titleMatch) titleMatch = block.match(/<a[^>]*class="c_l"[^>]*title="([^"]+)"/);
        if (titleMatch) title = decodeHTML(titleMatch[1]);
        if (!title) continue;

        // description
        var desc = "";
        var descMatch = block.match(/<p class="fw400 lh20 fs14 ls0\.2 c_s ells _2 mb4">([^<]+(?:<[^\/][^>]*>[^<]*<\/[^>]+>[^<]*)*)<\/p>/);
        if (descMatch) {
            desc = normalizeWhitespace(stripTags(decodeHTML(descMatch[1])));
        } else {
            var descStart = block.indexOf('class="fw400 lh20 fs14 ls0.2 c_s ells _2 mb4">');
            if (descStart > -1) {
                descStart = block.indexOf('>', descStart) + 1;
                var descEnd = block.indexOf('</p>', descStart);
                if (descEnd > -1) {
                    desc = normalizeWhitespace(stripTags(decodeHTML(block.substring(descStart, descEnd))));
                }
            }
        }

        // genre
        var genre = "";
        var genreMatch = block.match(/href="\/stories\/[^"]*" title="([^"]+)" class="c_m/);
        if (!genreMatch) genreMatch = block.match(/href="\/stories\/[^"]*"[^>]*>([^<]+)<\/a>/);
        if (genreMatch) genre = genreMatch[1];

        // author - strong.c_l.vam after the genre
        var author = "";
        var authorMatch = block.match(/<strong class="c_l vam fw400 lh16 fs12">([^<]+)<\/strong>/);
        if (authorMatch) author = decodeHTML(authorMatch[1]);

        novels.push({
            novelId: novelType + "__" + bookId,
            title: title,
            coverUrl: coverUrl,
            author: author,
            description: (genre ? genre + " • " : "") + desc
        });

        if (novels.length >= 50) break;
    }

    return novels;
}

var NovelSource = {

    getFilters: function() {
        return {
            contentType: {
                type: "select",
                label: "Content Type",
                options: [
                    { value: "novel", label: "Original Novels" },
                    { value: "fanfic", label: "Fan-Fiction" }
                ],
                default: "novel"
            },
            ranking: {
                type: "select",
                label: "Ranking",
                options: [
                    { value: "power_rank", label: "Power Ranking" },
                    { value: "best_sellers", label: "Trending" },
                    { value: "collection_rank", label: "Collections" },
                    { value: "popular_rank", label: "Popular" },
                    { value: "update_rank", label: "Updates" }
                ],
                default: "power_rank"
            }
        };
    },

    getPopularNovels: function(_page, filters) {
        filters = filters || {};
        var contentType = filters.contentType || "novel";
        var ranking = filters.ranking || "power_rank";

        var url;
        if (contentType === "fanfic") {
            url = baseUrl + "/ranking/fanfic/bi_annual/" + ranking;
        } else {
            url = baseUrl + "/ranking/novel/bi_annual/" + ranking + "?timeType=3&sourceType=2&signStatus=1";
        }

        log("Fetching popular: " + url);

        var response = fetch(url);
        if (!response || response.error || !response.ok) {
            log("Error fetching popular novels");
            return [];
        }

        var novelType = contentType === "fanfic" ? "f" : "n";
        var novels = parseNovelSections(response.text, novelType);
        log("Found " + novels.length + " novels");
        return novels;
    },

    searchNovels: function(query, page) {
        page = page || 1;
        var baseQuery = "/search?keywords=" + encodeURIComponent(query);
        if (page > 1) baseQuery += "&pageIndex=" + page;

        var searchTargets = [
            { url: baseUrl + baseQuery, novelType: "n" },
            { url: baseUrl + baseQuery + "&type=fanfic", novelType: "f" }
        ];

        var novels = [];

        for (var u = 0; u < searchTargets.length; u++) {
            var novelType = searchTargets[u].novelType;
            log("Searching: " + searchTargets[u].url);

            var response = fetch(searchTargets[u].url);
            if (!response || response.error || !response.ok) {
                log("Search error for type=" + novelType);
                continue;
            }

            var html = response.text;

            // Build author map from JSON-LD
            var authorMap = {};
            var ldPos = 0;
            while (ldPos < html.length) {
                var ldStart = html.indexOf('<script type="application/ld+json">', ldPos);
                if (ldStart === -1) break;
                var ldEnd = html.indexOf('</script>', ldStart);
                if (ldEnd === -1) break;
                var ldText = html.substring(ldStart + 35, ldEnd);
                ldPos = ldEnd + 1;
                try {
                    var ldJson = JSON.parse(ldText);
                    var items = ldJson.itemListElement || [];
                    for (var i = 0; i < items.length; i++) {
                        var item = items[i];
                        var itemUrl = item.url || "";
                        var idMatch = itemUrl.match(/_(\d+)$/);
                        if (idMatch && item.author && item.author.name) {
                            authorMap[idMatch[1]] = item.author.name;
                        }
                    }
                } catch (e) {}
            }

            // Parse <li class="pr pb20 mb12"> items
            var pos = 0;
            while (pos < html.length) {
                var liStart = html.indexOf('<li class="pr pb20 mb12">', pos);
                if (liStart === -1) break;
                var liEnd = html.indexOf('</li>', liStart);
                if (liEnd === -1) break;
                var block = html.substring(liStart, liEnd);
                pos = liEnd + 1;

                var bookId = "";
                var bidMatch = block.match(/data-bookid="([^"]+)"/);
                if (bidMatch) bookId = bidMatch[1];
                if (!bookId) continue;

                var title = "";
                var titleMatch = block.match(/<h3[^>]*>[\s\S]*?<a[^>]*title="([^"]+)"/);
                if (titleMatch) title = decodeHTML(titleMatch[1]);
                if (!title) continue;

                var coverUrl = "";
                var imgMatch = block.match(/<img[^>]+src="([^"]+)"/);
                if (imgMatch && imgMatch[1].indexOf("data:") !== 0) {
                    coverUrl = imgMatch[1].indexOf("//") === 0 ? "https:" + imgMatch[1] : imgMatch[1];
                }

                var genre = "";
                var genreMatch = block.match(/href="\/stories\/[^"]*"[^>]*>([^<]+)<\/a>/);
                if (genreMatch) genre = genreMatch[1];

                var desc = "";
                var descIdx = block.indexOf('class="fs16 c_000 ells _2 lh24">');
                if (descIdx > -1) {
                    var descOpen = block.indexOf('>', descIdx) + 1;
                    var descClose = block.indexOf('</p>', descOpen);
                    if (descClose > -1) desc = normalizeWhitespace(stripTags(decodeHTML(block.substring(descOpen, descClose))));
                }

                novels.push({
                    novelId: novelType + "__" + bookId,
                    title: title,
                    coverUrl: coverUrl,
                    author: authorMap[bookId] || "",
                    description: (genre ? genre + " • " : "") + desc
                });
            }
        }

        log("Search found " + novels.length + " novels");
        return novels;
    },

    getNovelDetails: function(novelId) {
        var bookId = getBookId(novelId);
        var url = baseUrl + "/book/" + bookId;
        log("Getting details for: " + url);

        var response = fetch(url);
        if (!response || response.error || !response.ok) {
            log("Error fetching novel details");
            return null;
        }

        var html = response.text;

        // title
        var title = "";
        var titleMatch = html.match(/<h1[^>]*class="[^"]*auto_height[^"]*"[^>]*>([^<]+)<\/h1>/);
        if (!titleMatch) titleMatch = html.match(/<h1[^>]*>([^<]+)<\/h1>/);
        if (titleMatch) title = decodeHTML(titleMatch[1].trim());

        // cover
        var coverUrl = "";
        var coverStart = html.indexOf('class="g_thumb"');
        if (coverStart > -1) {
            var coverBlock = html.substring(coverStart, coverStart + 500);
            var coverMatch = coverBlock.match(/src="([^"]+)"/);
            if (coverMatch && coverMatch[1].indexOf("data:") !== 0) {
                coverUrl = coverMatch[1].indexOf("//") === 0 ? "https:" + coverMatch[1] : coverMatch[1];
            }
        }

        // author
        var author = "";
        var authorMatch = html.match(/<a class="c_primary"[^>]*title="([^"]+)"/);
        if (authorMatch) author = decodeHTML(authorMatch[1]);

        // rating
        var rating = "";
        var ratingMatch = html.match(/<strong class="vam fs24 mr8">([^<]+)<\/strong>/);
        if (ratingMatch) rating = ratingMatch[1].trim();

        // genre
        var genre = "";
        var genreMatch = html.match(/class="det-hd-tag"[^>]*>[^<]*<span>([^<]+)<\/span>/);
        if (genreMatch) genre = genreMatch[1];

        // synopsis
        var synopsis = "";
        var synStart = html.indexOf('class="g_txt_over mb48 fs16 j_synopsis');
        if (synStart > -1) {
            var synBlock = html.substring(synStart, synStart + 5000);
            var pStart = synBlock.indexOf('<p class="c_000">');
            if (pStart > -1) {
                pStart += '<p class="c_000">'.length;
                var pEnd = synBlock.indexOf('</p>', pStart);
                if (pEnd > -1) {
                    synopsis = stripTags(decodeHTML(synBlock.substring(pStart, pEnd).replace(/<br\s*\/?>/gi, "\n")));
                    synopsis = normalizeWhitespace(synopsis);
                }
            }
        }

        // type badge: "Original" or "Fan-Fic"
        var typeMatch = html.match(/<strong class="pa t0 r0 z1">([^<]+)<\/strong>/);
        var typeLabel = typeMatch ? typeMatch[1].trim() : "";

        return {
            novelId: novelId,
            title: title,
            coverUrl: coverUrl,
            author: author,
            genres: genre ? [genre] : [],
            status: typeLabel,
            rating: rating,
            description: synopsis
        };
    },

    getChapterList: function(novelId) {
        var bookId = getBookId(novelId);
        var isFanfic = getNovelType(novelId) === "f";
        var url = baseUrl + "/book/" + bookId + "/catalog";
        log("Getting chapters from: " + url);

        var response = fetch(url);
        if (!response || response.error || !response.ok) {
            log("Error fetching catalog");
            return [];
        }

        var html = response.text;
        var chapters = [];
        var index = 0;

        // find catalog list container
        var catalogStart = html.indexOf('j_catalog_list');
        if (catalogStart === -1) {
            log("No catalog list found");
            return [];
        }

        var pos = catalogStart;

        while (pos < html.length) {
            // find each li with data-cid
            var liStart = html.indexOf('<li class="g_col _6"', pos);
            if (liStart === -1) break;

            var liEnd = html.indexOf('</li>', liStart);
            if (liEnd === -1) break;

            var liBlock = html.substring(liStart, liEnd);
            pos = liEnd + 1;

            // chapterId from data-cid
            var cidMatch = liBlock.match(/data-cid="([^"]+)"/);
            if (!cidMatch) continue;
            var chapterId = cidMatch[1];

            // is locked? look for i-lock reference
            var isLocked = liBlock.indexOf('#i-lock') > -1;

            // for originals, skip locked chapters
            if (!isFanfic && isLocked) continue;

            // title from the anchor title attribute
            var title = "";
            var titleMatch = liBlock.match(/<a[^>]*title="([^"]+)"/);
            if (titleMatch) title = decodeHTML(titleMatch[1]);
            if (!title) continue;

            chapters.push({
                chapterId: novelId + "/" + chapterId,
                title: title,
                index: index
            });
            index++;
        }

        log("Found " + chapters.length + " chapters (isFanfic=" + isFanfic + ")");
        return chapters;
    },

    getChapterContent: function(chapterId) {
        // chapterId format: "n__BOOKID/CHAPTERID"
        var slashPos = chapterId.indexOf("/");
        if (slashPos === -1) {
            return "<p>Error: invalid chapterId format</p>";
        }

        var novelId = chapterId.substring(0, slashPos);
        var chapNum = chapterId.substring(slashPos + 1);
        var bookId = getBookId(novelId);

        var url = baseUrl + "/book/" + bookId + "/" + chapNum;
        log("Fetching chapter: " + url);

        var response = fetch(url);
        if (!response || response.error || !response.ok) {
            return "<p>Error loading chapter. Status: " + (response ? response.status : "no response") + "</p>";
        }

        var html = response.text;

        // check if locked
        var lockMatch = html.match(/data-islock="([^"]+)"/);
        if (lockMatch && lockMatch[1] === "1") {
            return "<p>This chapter is locked and requires coins to unlock on Webnovel.</p>";
        }

        // find chapter content container
        var contentStart = html.indexOf('class="cha-words');
        if (contentStart === -1) {
            contentStart = html.indexOf('class="cha-content"');
        }
        if (contentStart === -1) {
            return "<p>Error: could not find chapter content</p>";
        }

        // find end of chapter content area
        var contentEnd = html.indexOf('class="user-links-wrap', contentStart);
        if (contentEnd === -1) contentEnd = html.indexOf('j_chapterLoading', contentStart);
        if (contentEnd === -1) contentEnd = contentStart + 100000;

        var contentBlock = html.substring(contentStart, contentEnd);
        var paragraphs = [];
        var pPos = 0;

        while (pPos < contentBlock.length) {
            // each paragraph is in <div class="db cha-paragraph ..."><div class="dib pr"><p>text</p>
            var paraStart = contentBlock.indexOf('<div class="db cha-paragraph', pPos);
            if (paraStart === -1) break;

            // need to find the closing </div> after the inner <p>
            var innerP = contentBlock.indexOf('<p>', paraStart);
            if (innerP === -1 || innerP > paraStart + 1000) {
                pPos = paraStart + 1;
                continue;
            }
            var innerPEnd = contentBlock.indexOf('</p>', innerP);
            if (innerPEnd === -1) {
                pPos = paraStart + 1;
                continue;
            }

            var pContent = contentBlock.substring(innerP + 3, innerPEnd);
            // strip any inline tags (comment icons etc)
            pContent = stripTags(pContent);
            pContent = decodeHTML(pContent);
            pContent = normalizeWhitespace(pContent);

            if (pContent.length > 0) {
                paragraphs.push("<p>" + pContent + "</p>");
            }

            pPos = innerPEnd + 1;
        }

        if (paragraphs.length === 0) {
            // fallback: grab all <p> tags from content block
            var fallbackPos = 0;
            while (fallbackPos < contentBlock.length) {
                var pStart = contentBlock.indexOf('<p>', fallbackPos);
                if (pStart === -1) break;
                var pEnd = contentBlock.indexOf('</p>', pStart);
                if (pEnd === -1) break;
                var text = stripTags(decodeHTML(contentBlock.substring(pStart + 3, pEnd)));
                text = normalizeWhitespace(text);
                if (text.length > 5) paragraphs.push("<p>" + text + "</p>");
                fallbackPos = pEnd + 1;
            }
        }

        if (paragraphs.length === 0) {
            return "<p>Error: no content found in chapter</p>";
        }

        log("Extracted " + paragraphs.length + " paragraphs");
        return paragraphs.join("\n");
    }
};

log("Webnovel plugin loaded");
