// Helper functions for Webnovel source

function extractBetween(text, start, end) {
    var startIndex = text.indexOf(start);
    if (startIndex === -1) return "";
    var textAfterStart = text.substring(startIndex + start.length);
    var endIndex = textAfterStart.indexOf(end);
    if (endIndex === -1) return textAfterStart;
    return textAfterStart.substring(0, endIndex);
}

function decodeHTML(text) {
    if (!text) return "";
    return text
        .replace(/&#x([0-9a-fA-F]+);/g, function(m, hex) { return String.fromCharCode(parseInt(hex, 16)); })
        .replace(/&#(\d+);/g, function(m, dec) { return String.fromCharCode(parseInt(dec, 10)); })
        .replace(/&amp;/g, "&")
        .replace(/&lt;/g, "<")
        .replace(/&gt;/g, ">")
        .replace(/&quot;/g, '"')
        .replace(/&#39;/g, "'")
        .replace(/&apos;/g, "'")
        .replace(/&nbsp;/g, " ");
}

function stripTags(text) {
    return text.replace(/<[^>]+>/g, "");
}

function normalizeWhitespace(text) {
    return text.replace(/\s{2,}/g, " ").trim();
}

function cleanContent(content) {
    content = content.replace(/<script[^>]*>[\s\S]*?<\/script>/gi, "");
    content = content.replace(/<style[^>]*>[\s\S]*?<\/style>/gi, "");
    return content;
}

// Extract bookId from novelId (format: "n__BOOKID" or "f__BOOKID")
function getBookId(novelId) {
    var sep = novelId.indexOf("__");
    if (sep === -1) return novelId;
    return novelId.substring(sep + 2);
}

// Get type prefix from novelId ("n" or "f")
function getNovelType(novelId) {
    var sep = novelId.indexOf("__");
    if (sep === -1) return "n";
    return novelId.substring(0, sep);
}
