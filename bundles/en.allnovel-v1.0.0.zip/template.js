// AllNovel source implementation
// Helper functions from helpers.js are available globally
// SourceMetadata is injected from source.json

// Initialize baseUrl from injected metadata
var baseUrl = SourceMetadata.baseURL;

// Helper function to extract chapter number from slug
function extractChapterNumber(slug) {
    // Slugs look like: chapter-2050-one-of-the-three-weapon-specialists.html
    var match = slug.match(/^chapter-(\d+)/i);
    if (match) {
        return parseInt(match[1], 10);
    }
    return 0;
}

// Helper function to get cover URL from a novel's detail page
function fetchCoverFromDetail(novelSlug) {
    var url = baseUrl + "/" + novelSlug + ".html";
    var response = fetch(url);

    if (!response || response.error || !response.ok) {
        return "";
    }

    var html = response.text;
    // Look for the cover image on detail page (larger portrait format)
    var imgMatch = html.match(/<img[^>]+src="(\/uploads\/thumbs\/[^"]+)"[^>]+alt="[^"]*"[^>]*>/);
    if (!imgMatch) {
        imgMatch = html.match(/<img[^>]+src="(\/uploads\/thumbs\/[^"]+)"[^>]*>/);
    }

    if (imgMatch) {
        return baseUrl + imgMatch[1];
    }
    return "";
}

// Helper function to parse novel list from HTML
function parseNovelList(html) {
    var novels = [];

    // Find all novel links ending in .html
    var titlePattern = /<h3[^>]*>[\s\S]*?<a[^>]+href="\/([^"]+\.html)"[^>]*>([^<]+)<\/a>/g;

    var seen = {};
    var match;

    // Extract titles first as they're more reliable
    while ((match = titlePattern.exec(html)) !== null) {
        var novelSlug = match[1].replace(".html", "");
        var title = match[2].trim();

        // Skip chapter links
        if (novelSlug.indexOf("/chapter-") > -1) {
            continue;
        }

        if (seen[novelSlug]) {
            continue;
        }
        seen[novelSlug] = true;

        novels.push({
            novelId: novelSlug,
            title: decodeHTML(title),
            coverUrl: "", // Will be fetched below
            author: "",
            description: ""
        });

        if (novels.length >= 20) {
            break;
        }
    }

    // Fetch proper cover images from each novel's detail page
    log("Fetching cover images for " + novels.length + " novels...");
    for (var i = 0; i < novels.length; i++) {
        var coverUrl = fetchCoverFromDetail(novels[i].novelId);
        if (coverUrl) {
            novels[i].coverUrl = coverUrl;
        }
    }

    log("Found " + novels.length + " novels with covers");
    return novels;
}

var NovelSource = {

    getFilters: function() {
        return {
            sort: {
                type: "select",
                label: "Sort By",
                options: [
                    { value: "hot", label: "Hot" },
                    { value: "latest", label: "Latest Release" },
                    { value: "completed", label: "Completed" }
                ],
                default: "hot"
            },
            genre: {
                type: "select",
                label: "Genre",
                options: [
                    { value: "", label: "All Genres" },
                    { value: "Action", label: "Action" },
                    { value: "Adult", label: "Adult" },
                    { value: "Adventure", label: "Adventure" },
                    { value: "Comedy", label: "Comedy" },
                    { value: "Drama", label: "Drama" },
                    { value: "Ecchi", label: "Ecchi" },
                    { value: "Fantasy", label: "Fantasy" },
                    { value: "Gender Bender", label: "Gender Bender" },
                    { value: "Harem", label: "Harem" },
                    { value: "Historical", label: "Historical" },
                    { value: "Horror", label: "Horror" },
                    { value: "Josei", label: "Josei" },
                    { value: "Martial Arts", label: "Martial Arts" },
                    { value: "Mature", label: "Mature" },
                    { value: "Mecha", label: "Mecha" },
                    { value: "Mystery", label: "Mystery" },
                    { value: "Psychological", label: "Psychological" },
                    { value: "Romance", label: "Romance" },
                    { value: "School Life", label: "School Life" },
                    { value: "Sci-fi", label: "Sci-fi" },
                    { value: "Seinen", label: "Seinen" },
                    { value: "Shoujo", label: "Shoujo" },
                    { value: "Shounen", label: "Shounen" },
                    { value: "Slice of Life", label: "Slice of Life" },
                    { value: "Smut", label: "Smut" },
                    { value: "Sports", label: "Sports" },
                    { value: "Supernatural", label: "Supernatural" },
                    { value: "Tragedy", label: "Tragedy" },
                    { value: "Wuxia", label: "Wuxia" },
                    { value: "Xianxia", label: "Xianxia" },
                    { value: "Xuanhuan", label: "Xuanhuan" },
                    { value: "Yaoi", label: "Yaoi" }
                ],
                default: ""
            }
        };
    },

    getPopularNovels: function(page, filters) {
        page = page || 1;
        filters = filters || {};

        log("Fetching popular novels, page: " + page + ", filters: " + JSON.stringify(filters));

        var url;

        if (filters.genre && filters.genre !== "") {
            var genreEncoded = filters.genre.replace(/ /g, "+");
            url = baseUrl + "/genre/" + genreEncoded + "?page=" + page;
            log("Using genre filter: " + filters.genre);
        } else if (filters.sort === "completed") {
            url = baseUrl + "/status/Completed?page=" + page;
        } else if (filters.sort === "latest") {
            url = baseUrl + "/latest-release?page=" + page;
        } else {
            url = baseUrl + "/hot-novel?page=" + page;
        }

        log("URL: " + url);

        try {
            var response = fetch(url);

            if (!response || response.error || !response.ok) {
                log("Error fetching novels: " + (response ? response.error || response.status : "no response"));
                return [];
            }

            var html = response.text;
            log("Received " + html.length + " characters");

            return parseNovelList(html);

        } catch (e) {
            log("Exception: " + e);
            return [];
        }
    },

    searchNovels: function(query, page) {
        log("Searching for: " + query + ", page: " + page);

        var url = baseUrl + "/search?keyword=" + encodeURIComponent(query);
        log("Search URL: " + url);

        var response = fetch(url);

        if (!response || response.error || !response.ok) {
            log("Error searching novels");
            return [];
        }

        var html = response.text;
        return parseNovelList(html);
    },

    getNovelDetails: function(novelId) {
        log("Getting details for novel: " + novelId);

        var url = baseUrl + "/" + novelId + ".html";
        var response = fetch(url);

        if (!response || response.error || !response.ok) {
            log("Error fetching novel details");
            return null;
        }

        var html = response.text;
        log("Got " + html.length + " chars for novel details");

        // Title - in h3 with class="title"
        var title = "";
        var titleMatch = html.match(/<h3\s+class="title">([^<]+)<\/h3>/);
        if (titleMatch) {
            title = titleMatch[1].trim();
        }
        log("Title: " + title);

        // Cover image
        var coverUrl = "";
        var imgMatch = html.match(/<img[^>]+src="(\/uploads\/thumbs\/[^"]+)"[^>]+alt="/);
        if (imgMatch) {
            coverUrl = baseUrl + imgMatch[1];
        }
        log("Cover: " + coverUrl);

        // Author - after "Author:" h3 tag
        var author = "";
        var authorSection = html.indexOf('<h3>Author:</h3>');
        if (authorSection > -1) {
            var authorArea = html.substring(authorSection, authorSection + 200);
            var authorMatch = authorArea.match(/<a\s+href="\/author\/[^"]+">([^<]+)<\/a>/);
            if (authorMatch) {
                author = authorMatch[1].trim();
            }
        }
        log("Author: " + author);

        // Genres - in Genre section
        var genres = [];
        var genreSection = html.indexOf('<h3>Genre:</h3>');
        if (genreSection > -1) {
            var genreArea = html.substring(genreSection, genreSection + 500);
            var genrePattern = /<a\s+href="\/genre\/[^"]+">([^<]+)<\/a>/g;
            var match;
            while ((match = genrePattern.exec(genreArea)) !== null) {
                if (genres.length < 5) {
                    genres.push(match[1].trim());
                }
            }
        }
        log("Genres: " + genres.join(", "));

        // Status
        var status = "Unknown";
        var statusSection = html.indexOf('<h3>Status:</h3>');
        if (statusSection > -1) {
            var statusArea = html.substring(statusSection, statusSection + 100);
            var statusMatch = statusArea.match(/<a\s+href="\/status\/[^"]+">([^<]+)<\/a>/);
            if (statusMatch) {
                status = statusMatch[1].trim();
            }
        }
        log("Status: " + status);

        // Description - in desc-text div
        var description = "";
        var descStart = html.indexOf('<div class="desc-text">');
        if (descStart > -1) {
            var descEnd = html.indexOf('</div>', descStart + 23);
            if (descEnd > -1) {
                var descHTML = html.substring(descStart + 23, descEnd);
                // Extract paragraphs
                var paragraphs = [];
                var pPattern = /<p>([^<]+)<\/p>/g;
                var pMatch;
                while ((pMatch = pPattern.exec(descHTML)) !== null) {
                    paragraphs.push(pMatch[1].trim());
                }
                description = paragraphs.join(" ");
                description = decodeHTML(description);
                description = normalizeWhitespace(description);
            }
        }
        log("Description length: " + description.length);

        return {
            novelId: novelId,
            title: decodeHTML(title),
            coverUrl: coverUrl,
            author: decodeHTML(author),
            genres: genres,
            status: status,
            rating: "0.0",
            description: decodeHTML(description)
        };
    },

    getChapterList: function(novelId) {
        log("Getting chapters for novel: " + novelId);

        var url = baseUrl + "/" + novelId + ".html";
        var response = fetch(url);

        if (!response || response.error || !response.ok) {
            log("Error fetching chapter list");
            return [];
        }

        var html = response.text;
        var chapters = [];
        var seen = {};
        var latestChapters = []; // Store latest chapters to add at end

        // First, capture the "Latest chapters" section (most recent 5)
        var latestStart = html.indexOf('class="l-chapters"');
        log("latestStart index: " + latestStart);
        if (latestStart > -1) {
            var latestEnd = html.indexOf('</ul>', latestStart);
            log("latestEnd index: " + latestEnd);
            if (latestEnd > -1) {
                var latestSection = html.substring(latestStart, latestEnd);
                log("latestSection length: " + latestSection.length);
                var escapedIdLatest = novelId.replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&');
                var latestPattern = new RegExp('<a[^>]+href="/' + escapedIdLatest + '/([^"]+\\.html)"[^>]+title="([^"]+)"', 'g');
                var latestMatch;
                while ((latestMatch = latestPattern.exec(latestSection)) !== null) {
                    log("Found latest chapter: " + latestMatch[1] + " - " + latestMatch[2]);
                    latestChapters.push({
                        slug: latestMatch[1],
                        title: latestMatch[2].trim()
                    });
                }
                log("Total latest chapters found: " + latestChapters.length);
            }
        } else {
            log("Could not find l-chapters section");
        }

        // Find the main chapter list section
        var listStart = html.indexOf('id="list-chapter"');
        if (listStart > -1) {
            html = html.substring(listStart);
        }

        // Chapter links have: href="/novel-slug/chapter-X.html" title="Chapter Title"
        var escapedId = novelId.replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&');
        var chapterPattern = new RegExp('<a[^>]+href="/' + escapedId + '/([^"]+\\.html)"[^>]+title="([^"]+)"', 'g');

        var match;
        while ((match = chapterPattern.exec(html)) !== null) {
            var chapterSlug = match[1];
            var chapterTitle = match[2].trim();

            if (seen[chapterSlug]) {
                continue;
            }
            seen[chapterSlug] = true;

            // Extract actual chapter number from slug
            var chapterNum = extractChapterNumber(chapterSlug);

            // Clean up chapter title - remove "Chapter X - " prefix if present
            chapterTitle = chapterTitle.replace(/^Chapter\s+\d+\s*[-–:]\s*/i, "");

            chapters.push({
                chapterId: novelId + "/" + chapterSlug,
                title: decodeHTML(chapterTitle),
                index: chapterNum > 0 ? chapterNum - 1 : chapters.length  // Use actual chapter number (0-indexed)
            });
        }

        log("Found " + chapters.length + " chapters on first page");

        // Check if there are multiple pages of chapters
        // Look for: <a href="/novel.html?page=56" ...>Last
        var pageMatch = html.match(/\?page=(\d+)"[^>]*>Last/i);
        if (!pageMatch) {
            // Try alternate pattern with class="last"
            pageMatch = html.match(/class="last"[^>]*href="[^"]*\?page=(\d+)"/i);
        }
        if (!pageMatch) {
            // Try finding the highest page number
            var allPages = html.match(/\?page=(\d+)/g);
            if (allPages && allPages.length > 0) {
                var maxPage = 1;
                for (var i = 0; i < allPages.length; i++) {
                    var num = parseInt(allPages[i].replace("?page=", ""), 10);
                    if (num > maxPage) maxPage = num;
                }
                if (maxPage > 1) {
                    pageMatch = [null, maxPage.toString()];
                }
            }
        }

        if (pageMatch) {
            var lastPage = parseInt(pageMatch[1], 10);
            log("Found " + lastPage + " pages of chapters");

            // Fetch remaining pages
            for (var p = 2; p <= lastPage && p <= 100; p++) {
                var pageUrl = url + "?page=" + p;
                log("Fetching chapter page " + p);

                var pageResponse = fetch(pageUrl);
                if (!pageResponse || pageResponse.error || !pageResponse.ok) {
                    break;
                }

                var pageHtml = pageResponse.text;
                var pageChapterPattern = new RegExp('<a[^>]+href="/' + escapedId + '/([^"]+\\.html)"[^>]+title="([^"]+)"', 'g');

                while ((match = pageChapterPattern.exec(pageHtml)) !== null) {
                    var chapterSlug = match[1];
                    var chapterTitle = match[2].trim();

                    if (seen[chapterSlug]) {
                        continue;
                    }
                    seen[chapterSlug] = true;

                    var chapterNum = extractChapterNumber(chapterSlug);
                    chapterTitle = chapterTitle.replace(/^Chapter\s+\d+\s*[-–:]\s*/i, "");

                    chapters.push({
                        chapterId: novelId + "/" + chapterSlug,
                        title: decodeHTML(chapterTitle),
                        index: chapterNum > 0 ? chapterNum - 1 : chapters.length
                    });
                }
            }
        }

        // Add latest chapters at the end (they're the most recent)
        log("Adding latest chapters. latestChapters.length = " + latestChapters.length);
        var addedLatest = 0;
        for (var j = 0; j < latestChapters.length; j++) {
            var latest = latestChapters[j];
            log("Checking latest chapter: " + latest.slug + " - already seen: " + (seen[latest.slug] ? "yes" : "no"));
            if (seen[latest.slug]) {
                continue;
            }
            seen[latest.slug] = true;

            var latestChapterNum = extractChapterNumber(latest.slug);
            var latestTitle = latest.title.replace(/^Chapter\s+\d+\s*[-–:]\s*/i, "");
            chapters.push({
                chapterId: novelId + "/" + latest.slug,
                title: decodeHTML(latestTitle),
                index: latestChapterNum > 0 ? latestChapterNum - 1 : chapters.length
            });
            addedLatest++;
            log("Added latest chapter: " + latest.slug);
        }

        log("Added " + addedLatest + " latest chapters");
        log("Found " + chapters.length + " total chapters for " + novelId);
        return chapters;
    },

    getChapterContent: function(chapterId) {
        log("Getting content for chapter: " + chapterId);

        var url = baseUrl + "/" + chapterId;
        log("Fetching from: " + url);

        var response = fetch(url);

        if (!response || response.error) {
            return "<p>Error loading chapter content: " + (response ? response.error : "Network error") + "</p>";
        }

        if (!response.ok) {
            return "<p>Error loading chapter content. Status: " + response.status + "</p>";
        }

        var html = response.text;
        var content = "";

        // Look for chapter-content div
        var contentStart = html.indexOf('id="chapter-content"');
        if (contentStart === -1) {
            contentStart = html.indexOf('class="chapter-content"');
        }
        if (contentStart === -1) {
            contentStart = html.indexOf('id="chapter"');
        }

        if (contentStart > -1) {
            // Find the opening tag
            var tagStart = html.lastIndexOf('<', contentStart);
            if (tagStart > -1) {
                // Find closing div - we need to be smart about nested divs
                var depth = 1;
                var searchPos = contentStart + 20;
                var endPos = html.length;

                while (searchPos < html.length && depth > 0) {
                    var nextOpen = html.indexOf('<div', searchPos);
                    var nextClose = html.indexOf('</div>', searchPos);

                    if (nextClose === -1) {
                        break;
                    }

                    if (nextOpen !== -1 && nextOpen < nextClose) {
                        depth++;
                        searchPos = nextOpen + 4;
                    } else {
                        depth--;
                        if (depth === 0) {
                            endPos = nextClose;
                        }
                        searchPos = nextClose + 6;
                    }
                }

                var contentHTML = html.substring(tagStart, endPos);

                // Clean up content
                contentHTML = cleanContent(contentHTML);

                // Extract paragraphs
                var paragraphPattern = /<p[^>]*>([\s\S]*?)<\/p>/g;
                var paragraphs = [];
                var match;

                while ((match = paragraphPattern.exec(contentHTML)) !== null) {
                    var pContent = match[1].trim();

                    // Skip ads/watermarks
                    if (pContent.indexOf("allnovel") > -1 ||
                        pContent.indexOf("<script") > -1 ||
                        pContent.indexOf("<div") > -1 ||
                        pContent.length < 5) {
                        continue;
                    }

                    pContent = stripTags(pContent);
                    pContent = decodeHTML(pContent);
                    pContent = normalizeWhitespace(pContent);

                    if (pContent.length > 5) {
                        paragraphs.push("<p>" + pContent + "</p>");
                    }
                }

                if (paragraphs.length > 0) {
                    content = paragraphs.join("\n");
                    log("Extracted " + paragraphs.length + " paragraphs");
                }
            }
        }

        // Fallback: try to find content between navigation elements
        if (!content || content.length < 100) {
            log("Trying fallback extraction method");

            var startMarker = "Prev Chapter";
            var startIndex = html.indexOf(startMarker);
            if (startIndex === -1) {
                startMarker = "prev_chap";
                startIndex = html.indexOf(startMarker);
            }

            if (startIndex > -1) {
                var endMarkers = ["Next Chapter", "next_chap", '<div class="chapter_nav">', '<div class="row">'];
                var endIndex = html.length;

                for (var i = 0; i < endMarkers.length; i++) {
                    var idx = html.indexOf(endMarkers[i], startIndex + 100);
                    if (idx > -1 && idx < endIndex) {
                        endIndex = idx;
                    }
                }

                var contentSection = html.substring(startIndex, endIndex);
                contentSection = cleanContent(contentSection);

                var paragraphPattern = /<p[^>]*>([\s\S]*?)<\/p>/g;
                var paragraphs = [];
                var match;

                while ((match = paragraphPattern.exec(contentSection)) !== null) {
                    var pContent = match[1].trim();
                    pContent = stripTags(pContent);
                    pContent = decodeHTML(pContent);
                    pContent = normalizeWhitespace(pContent);

                    if (pContent.length > 10) {
                        paragraphs.push("<p>" + pContent + "</p>");
                    }
                }

                if (paragraphs.length > 0) {
                    content = paragraphs.join("\n");
                }
            }
        }

        if (!content || content.trim().length < 50) {
            return "<p>Chapter content could not be extracted. The website structure may have changed.</p>";
        }

        log("Successfully extracted " + content.length + " characters");
        return content;
    }
};

log("AllNovel plugin loaded successfully");
