// NovelBin source implementation
// Helper functions from helpers.js are available globally
// SourceMetadata is injected from source.json

// Initialize baseUrl from injected metadata
var baseUrl = SourceMetadata.baseURL;

// Regex to fix poster URLs - replace /novel_123_456/ with /novel/
var fullPosterRegex = /\/novel_[0-9]*_[0-9]*\//;

// Helper to fix cover URL
function fixCoverUrl(url) {
    if (!url) return "";
    return url.replace(fullPosterRegex, "/novel/");
}

// Helper to extract chapter number from slug
function extractChapterNumber(slug) {
    var match = slug.match(/chapter-(\d+)/i);
    if (match) {
        return parseInt(match[1], 10);
    }
    return 0;
}

// Helper function to fetch cover URL from a novel's detail page
function fetchCoverFromDetail(novelSlug) {
    var url = baseUrl + "/b/" + novelSlug;
    var response = fetch(url);

    if (!response || response.error || !response.ok) {
        return "";
    }

    var html = response.text;

    // Look for cover image - try multiple patterns
    // Pattern 1: img with src containing images.novelbin.com
    var imgMatch = html.match(/<img[^>]+src="(https:\/\/images\.novelbin\.com\/[^"]+)"/i);
    if (imgMatch) {
        return imgMatch[1];
    }

    // Pattern 2: img with data-src
    imgMatch = html.match(/<img[^>]+data-src="(https:\/\/images\.novelbin\.com\/[^"]+)"/i);
    if (imgMatch) {
        return imgMatch[1];
    }

    // Pattern 3: meta itemprop="image"
    imgMatch = html.match(/<meta[^>]+itemprop="image"[^>]+content="([^"]+)"/i);
    if (imgMatch) {
        return imgMatch[1];
    }

    return "";
}

// Helper function to parse novel list from HTML
function parseNovelList(html) {
    var novels = [];
    var seen = {};

    // NovelBin uses /b/novel-slug format for URLs
    // Pattern: <h3 class="novel-title"><a href="https://novelbin.com/b/slug" title="Title">Title</a></h3>

    // Pattern 1: h3 with novel-title class containing anchor with href to /b/
    var titlePattern = /<h3\s+class="novel-title">\s*<a\s+href="([^"]+\/b\/[^"]+)"[^>]*title="([^"]+)"[^>]*>/gi;

    var match;
    while ((match = titlePattern.exec(html)) !== null && novels.length < 20) {
        var novelUrl = match[1];
        var title = match[2].trim();

        // Skip if it's a chapter link
        if (novelUrl.indexOf("/chapter") > -1) continue;
        if (title.length < 2) continue;

        // Extract novel ID from URL - format: /b/novel-slug or full URL
        var idMatch = novelUrl.match(/\/b\/([^\/\?"]+)/);
        if (!idMatch) continue;

        var novelId = idMatch[1];

        if (seen[novelId]) continue;
        seen[novelId] = true;

        novels.push({
            novelId: novelId,
            title: decodeHTML(title),
            coverUrl: "",
            author: "",
            description: ""
        });
    }

    log("Found " + novels.length + " novels from title pattern");

    // Fetch cover images from each novel's detail page
    log("Fetching cover images for " + novels.length + " novels...");
    for (var i = 0; i < novels.length; i++) {
        var coverUrl = fetchCoverFromDetail(novels[i].novelId);
        if (coverUrl) {
            novels[i].coverUrl = coverUrl;
        }
    }

    log("Found " + novels.length + " novels total");
    return novels;
}

// Fallback function to parse chapters directly from the novel page
function parseChaptersFromPage(html, novelId) {
    var chapters = [];
    var seen = {};

    // First, find the chapter list section
    var listStart = html.indexOf('id="list-chapter"');
    if (listStart === -1) {
        listStart = html.indexOf('class="list-chapter"');
    }
    if (listStart === -1) {
        listStart = html.indexOf('id="tab-chapters"');
    }

    var workingHtml = listStart > -1 ? html.substring(listStart) : html;
    log("Working with " + workingHtml.length + " chars for chapter parsing");

    // Pattern to match chapter links - more flexible with whitespace
    // Format: <a href="URL" title="Title"> or with attributes in different order
    var chapterPattern = /<a[^>]+href="(https?:\/\/novelbin\.com\/b\/[^"]+\/[^"]+)"[^>]+title="([^"]+)"/gi;

    var match;
    var matchCount = 0;
    while ((match = chapterPattern.exec(workingHtml)) !== null) {
        matchCount++;
        var chapterUrl = match[1];
        var chapterTitle = match[2].trim();

        // Skip if title is too short
        if (chapterTitle.length < 3) continue;

        // Extract chapter slug from URL
        var chapterIdMatch = chapterUrl.match(/\/b\/[^\/]+\/(.+)$/);
        if (!chapterIdMatch) continue;

        var chapterSlug = chapterIdMatch[1];

        // Use the novelId passed in, not the one from URL (in case of mismatch)
        var chapterId = novelId + "/" + chapterSlug;

        if (seen[chapterSlug]) continue;
        seen[chapterSlug] = true;

        var chapterNum = extractChapterNumber(chapterSlug);

        chapters.push({
            chapterId: chapterId,
            title: decodeHTML(chapterTitle),
            index: chapterNum > 0 ? chapterNum - 1 : chapters.length
        });
    }

    log("Matched " + matchCount + " chapter links, parsed " + chapters.length + " unique chapters");

    // If we got very few chapters, the page might use pagination
    // Check for "Show more chapters" or pagination links
    if (chapters.length < 50) {
        var paginationMatch = html.match(/data-page="(\d+)"\s*class="[^"]*last/i);
        if (paginationMatch) {
            log("Found pagination with " + paginationMatch[1] + " pages - chapters may be incomplete");
        }
    }

    return chapters;
}

// Parse chapters from AJAX response
function parseChaptersFromAjax(html, novelId) {
    var chapters = [];
    var seen = {};

    log("Parsing AJAX response, length: " + html.length);

    // The AJAX might return list-chapter structure similar to the page
    // Pattern: <a href="URL" title="Title">
    var chapterPattern = /<a[^>]+href="([^"]+)"[^>]+title="([^"]+)"/gi;

    var match;
    while ((match = chapterPattern.exec(html)) !== null) {
        var chapterUrl = match[1];
        var chapterTitle = match[2].trim();

        if (!chapterUrl || chapterUrl === "#") continue;
        if (chapterTitle.length < 2) continue;

        // Extract chapter slug from URL
        var chapterIdMatch = chapterUrl.match(/\/b\/[^\/]+\/(.+)$/);
        if (!chapterIdMatch) {
            // Try without /b/ prefix
            chapterIdMatch = chapterUrl.match(/\/([^\/]+)$/);
        }
        if (!chapterIdMatch) continue;

        var chapterSlug = chapterIdMatch[1];
        var chapterId = novelId + "/" + chapterSlug;

        if (seen[chapterSlug]) continue;
        seen[chapterSlug] = true;

        var chapterNum = extractChapterNumber(chapterSlug);

        chapters.push({
            chapterId: chapterId,
            title: decodeHTML(chapterTitle),
            index: chapterNum > 0 ? chapterNum - 1 : chapters.length
        });
    }

    log("Parsed " + chapters.length + " chapters from AJAX");
    return chapters;
}

var NovelSource = {

    getFilters: function() {
        return {
            sort: {
                type: "select",
                label: "Sort By",
                options: [
                    { value: "top-hot-novel", label: "Hot Novel" },
                    { value: "latest", label: "Latest Release" },
                    { value: "completed", label: "Completed Novel" },
                    { value: "top-view-novel", label: "Most Popular" }
                ],
                default: "top-hot-novel"
            },
            genre: {
                type: "select",
                label: "Genre",
                options: [
                    { value: "", label: "All Genres" },
                    { value: "action", label: "Action" },
                    { value: "adventure", label: "Adventure" },
                    { value: "anime-&-comics", label: "Anime & Comics" },
                    { value: "comedy", label: "Comedy" },
                    { value: "drama", label: "Drama" },
                    { value: "eastern", label: "Eastern" },
                    { value: "fanfiction", label: "Fanfiction" },
                    { value: "fantasy", label: "Fantasy" },
                    { value: "game", label: "Game" },
                    { value: "gender-bender", label: "Gender Bender" },
                    { value: "harem", label: "Harem" },
                    { value: "historical", label: "Historical" },
                    { value: "horror", label: "Horror" },
                    { value: "isekai", label: "Isekai" },
                    { value: "josei", label: "Josei" },
                    { value: "litrpg", label: "LitRPG" },
                    { value: "magic", label: "Magic" },
                    { value: "magical-realism", label: "Magical Realism" },
                    { value: "martial-arts", label: "Martial Arts" },
                    { value: "mature", label: "Mature" },
                    { value: "mecha", label: "Mecha" },
                    { value: "modern-life", label: "Modern Life" },
                    { value: "mystery", label: "Mystery" },
                    { value: "psychological", label: "Psychological" },
                    { value: "reincarnation", label: "Reincarnation" },
                    { value: "romance", label: "Romance" },
                    { value: "school-life", label: "School Life" },
                    { value: "sci-fi", label: "Sci-fi" },
                    { value: "seinen", label: "Seinen" },
                    { value: "shoujo", label: "Shoujo" },
                    { value: "shoujo-ai", label: "Shoujo Ai" },
                    { value: "shounen", label: "Shounen" },
                    { value: "shounen-ai", label: "Shounen Ai" },
                    { value: "slice-of-life", label: "Slice of Life" },
                    { value: "smut", label: "Smut" },
                    { value: "sports", label: "Sports" },
                    { value: "supernatural", label: "Supernatural" },
                    { value: "system", label: "System" },
                    { value: "tragedy", label: "Tragedy" },
                    { value: "urban-life", label: "Urban Life" },
                    { value: "video-games", label: "Video Games" },
                    { value: "wuxia", label: "Wuxia" },
                    { value: "xianxia", label: "Xianxia" },
                    { value: "xuanhuan", label: "Xuanhuan" },
                    { value: "yaoi", label: "Yaoi" },
                    { value: "yuri", label: "Yuri" }
                ],
                default: ""
            }
        };
    },

    getPopularNovels: function(page, filters) {
        page = page || 1;
        filters = filters || {};

        log("Fetching popular novels, page: " + page + ", filters: " + JSON.stringify(filters));

        var url;

        if (filters.genre && filters.genre !== "") {
            // Genre filter takes priority
            url = baseUrl + "/genre/" + filters.genre + "?page=" + page;
        } else {
            // Use sort filter
            var sort = filters.sort || "top-hot-novel";
            url = baseUrl + "/sort/" + sort + "?page=" + page;
        }

        log("URL: " + url);

        try {
            var response = fetch(url);

            if (!response || response.error || !response.ok) {
                log("Error fetching novels: " + (response ? response.error || response.status : "no response"));
                return [];
            }

            var html = response.text;
            log("Received " + html.length + " characters");

            return parseNovelList(html);

        } catch (e) {
            log("Exception: " + e);
            return [];
        }
    },

    searchNovels: function(query, page) {
        log("Searching for: " + query + ", page: " + page);

        var url = baseUrl + "/search?keyword=" + encodeURIComponent(query);
        log("Search URL: " + url);

        var response = fetch(url);

        if (!response || response.error || !response.ok) {
            log("Error searching novels");
            return [];
        }

        var html = response.text;
        return parseNovelList(html);
    },

    getNovelDetails: function(novelId) {
        log("Getting details for novel: " + novelId);

        // NovelBin uses /b/novel-slug format (no .html extension)
        var url = baseUrl + "/b/" + novelId;

        var response = fetch(url);

        if (!response || response.error || !response.ok) {
            log("Error fetching novel details");
            return null;
        }

        var html = response.text;
        log("Got " + html.length + " chars for novel details");

        // Title - h3.title
        var title = "";
        var titleMatch = html.match(/<h3[^>]*class="title"[^>]*>([^<]+)<\/h3>/);
        if (titleMatch) {
            title = titleMatch[1].trim();
        }
        log("Title: " + title);

        // Cover image - div.book > img with data-src
        var coverUrl = "";
        var imgMatch = html.match(/<div[^>]*class="[^"]*book[^"]*"[^>]*>[\s\S]*?<img[^>]+data-src="([^"]+)"/);
        if (imgMatch) {
            coverUrl = fixCoverUrl(imgMatch[1]);
        }
        log("Cover: " + coverUrl);

        // Author - look for author link or span
        var author = "";
        // Pattern 1: Link to /author/name
        var authorMatch = html.match(/<a[^>]+href="[^"]*\/author\/[^"]*"[^>]*>([^<]+)<\/a>/i);
        if (authorMatch) {
            author = authorMatch[1].trim();
        }
        // Pattern 2: span with class="author" - extract just the text without icons
        if (!author || author === "More from author") {
            authorMatch = html.match(/<span[^>]*class="[^"]*author[^"]*"[^>]*>[^<]*<\/span>\s*([^<]+)/i);
            if (authorMatch) {
                author = authorMatch[1].trim();
            }
        }
        // Pattern 3: Look in info section for Author: label
        if (!author || author === "More from author") {
            var authorSection = html.match(/Author[:\s]*<\/h3>[\s\S]*?<a[^>]+>([^<]+)<\/a>/i);
            if (authorSection) {
                author = authorSection[1].trim();
            }
        }
        log("Author: " + author);

        // Status - usually 3rd li in ul.info
        var status = "Unknown";
        var statusMatch = html.match(/<a[^>]+href="[^"]*(?:status|completed|ongoing)[^"]*"[^>]*>([^<]+)<\/a>/i);
        if (statusMatch) {
            status = statusMatch[1].trim();
        }
        log("Status: " + status);

        // Genres - ul.info li with genre links
        var genres = [];
        var genreSection = html.match(/<ul[^>]*class="[^"]*info[^"]*"[^>]*>([\s\S]*?)<\/ul>/);
        if (genreSection) {
            var genrePattern = /<a[^>]+href="[^"]*\/genre\/[^"]*"[^>]*>([^<]+)<\/a>/gi;
            var match;
            while ((match = genrePattern.exec(genreSection[1])) !== null) {
                if (genres.length < 10) {
                    genres.push(match[1].trim());
                }
            }
        }
        log("Genres: " + genres.join(", "));

        // Description - div.desc-text
        var description = "";
        var descMatch = html.match(/<div[^>]*class="[^"]*desc-text[^"]*"[^>]*>([\s\S]*?)<\/div>/);
        if (descMatch) {
            // Extract text, strip tags
            description = descMatch[1];
            description = description.replace(/<br\s*\/?>/gi, "\n");
            description = stripTags(description);
            description = decodeHTML(description);
            description = normalizeWhitespace(description);
        }
        log("Description length: " + description.length);

        // Rating
        var rating = "0.0";
        var ratingMatch = html.match(/<span[^>]*class="[^"]*rate[^"]*"[^>]*>([0-9.]+)<\/span>/);
        if (ratingMatch) {
            rating = ratingMatch[1];
        }

        return {
            novelId: novelId,
            title: decodeHTML(title),
            coverUrl: coverUrl,
            author: decodeHTML(author),
            genres: genres,
            status: status,
            rating: rating,
            description: description
        };
    },

    getChapterList: function(novelId) {
        log("Getting chapters for novel: " + novelId);

        // NovelBin uses /b/novel-slug format
        var url = baseUrl + "/b/" + novelId;

        var response = fetch(url);

        if (!response || response.error || !response.ok) {
            log("Error fetching chapter list page");
            return [];
        }

        var html = response.text;

        // Extract data-novel-id (can be slug or numeric)
        var dataNovelId = "";

        // Look in the rating div for data-novel-id attribute (can be slug like "mirror-dream-tree")
        var ratingMatch = html.match(/id\s*=\s*["']rating["'][^>]*data-novel-id\s*=\s*["']([^"']+)["']/i);
        if (ratingMatch) {
            dataNovelId = ratingMatch[1];
            log("Found data-novel-id from rating: " + dataNovelId);
        }

        // Alternative: data-novel-id anywhere
        if (!dataNovelId) {
            ratingMatch = html.match(/data-novel-id\s*=\s*["']([^"']+)["']/i);
            if (ratingMatch) {
                dataNovelId = ratingMatch[1];
                log("Found data-novel-id: " + dataNovelId);
            }
        }

        // If we have a novel ID (slug or numeric), try the AJAX endpoint
        if (dataNovelId) {
            var ajaxUrl = baseUrl + "/ajax/chapter-archive?novelId=" + dataNovelId;
            log("Trying AJAX endpoint: " + ajaxUrl);

            var chapterResponse = fetch(ajaxUrl);

            if (chapterResponse && !chapterResponse.error && chapterResponse.ok) {
                var chapterHtml = chapterResponse.text;
                log("Got " + chapterHtml.length + " chars from AJAX");

                var chapters = parseChaptersFromAjax(chapterHtml, novelId);
                if (chapters.length > 0) {
                    log("Got " + chapters.length + " chapters from AJAX");
                    return chapters;
                }
            } else {
                log("AJAX request failed, trying page parsing");
            }
        }

        // Fallback: parse chapters directly from the page
        log("Parsing chapters from page HTML");
        return parseChaptersFromPage(html, novelId);
    },

    getChapterContent: function(chapterId) {
        log("Getting content for chapter: " + chapterId);

        var url = chapterId;
        if (url.indexOf("http") !== 0) {
            // NovelBin uses /b/novel-slug/chapter-slug format
            url = baseUrl + "/b/" + chapterId;
        }

        log("Fetching from: " + url);

        var response = fetch(url);

        if (!response || response.error) {
            return "<p>Error loading chapter content: " + (response ? response.error : "Network error") + "</p>";
        }

        if (!response.ok) {
            return "<p>Error loading chapter content. Status: " + response.status + "</p>";
        }

        var html = response.text;
        var content = "";

        // Look for #chapter-content or #chr-content
        var contentStart = html.indexOf('id="chapter-content"');
        if (contentStart === -1) {
            contentStart = html.indexOf('id="chr-content"');
        }
        if (contentStart === -1) {
            contentStart = html.indexOf('class="chr-content"');
        }

        if (contentStart > -1) {
            // Find the opening tag
            var tagStart = html.lastIndexOf('<', contentStart);
            if (tagStart > -1) {
                // Find closing div
                var depth = 1;
                var searchPos = contentStart + 20;
                var endPos = html.length;

                while (searchPos < html.length && depth > 0) {
                    var nextOpen = html.indexOf('<div', searchPos);
                    var nextClose = html.indexOf('</div>', searchPos);

                    if (nextClose === -1) {
                        break;
                    }

                    if (nextOpen !== -1 && nextOpen < nextClose) {
                        depth++;
                        searchPos = nextOpen + 4;
                    } else {
                        depth--;
                        if (depth === 0) {
                            endPos = nextClose;
                        }
                        searchPos = nextClose + 6;
                    }
                }

                content = html.substring(tagStart, endPos + 6);
            }
        }

        if (!content) {
            log("Could not find chapter content container");
            return "<p>Chapter content could not be extracted.</p>";
        }

        // Clean up content
        content = cleanContent(content);

        // Remove ad iframes
        content = content.replace(/<iframe[^>]*src="[^"]*ad[^"]*"[^>]*><\/iframe>/gi, "");

        // Remove watermarks
        var watermarks = [
            "If you find any errors ( broken links, non-standard content, etc.. ), Please let us know",
            "If you find any errors ( Ads popup, ads redirect, broken links, non-standard content, etc.. ), Please let us know",
            "[Updated from F r e e w e b n o v e l. c o m]",
            "report chapter",
            "freewebnovel.com",
            "novelbin.com"
        ];

        for (var i = 0; i < watermarks.length; i++) {
            content = content.split(watermarks[i]).join("");
        }

        // Extract paragraphs
        var paragraphPattern = /<p[^>]*>([\s\S]*?)<\/p>/gi;
        var paragraphs = [];
        var match;

        while ((match = paragraphPattern.exec(content)) !== null) {
            var pContent = match[1].trim();

            // Skip empty or ad content
            if (pContent.length < 5) continue;
            if (pContent.indexOf("<script") > -1) continue;
            if (pContent.indexOf("<iframe") > -1) continue;

            pContent = stripTags(pContent);
            pContent = decodeHTML(pContent);
            pContent = normalizeWhitespace(pContent);

            if (pContent.length > 5) {
                paragraphs.push("<p>" + pContent + "</p>");
            }
        }

        if (paragraphs.length > 0) {
            content = paragraphs.join("\n");
            log("Extracted " + paragraphs.length + " paragraphs");
        } else {
            // Fallback - return cleaned content as-is
            content = stripTags(content);
            content = decodeHTML(content);
            content = "<p>" + content + "</p>";
        }

        if (content.length < 100) {
            return "<p>Chapter content could not be extracted. The website structure may have changed.</p>";
        }

        log("Successfully extracted " + content.length + " characters");
        return content;
    }
};

log("NovelBin plugin loaded successfully");
