// Helper functions for Genesis Studio source
// These functions are available globally in template.js

function extractBetween(text, start, end) {
    var startIndex = text.indexOf(start);
    if (startIndex === -1) return "";
    var textAfterStart = text.substring(startIndex + start.length);
    var endIndex = textAfterStart.indexOf(end);
    if (endIndex === -1) return textAfterStart;
    return textAfterStart.substring(0, endIndex);
}

function extractAll(text, pattern) {
    var results = [];
    var match;
    while ((match = pattern.exec(text)) !== null) {
        results.push(match);
    }
    return results;
}

function decodeHTML(text) {
    return text
        .replace(/&amp;/g, "&")
        .replace(/&lt;/g, "<")
        .replace(/&gt;/g, ">")
        .replace(/&quot;/g, '"')
        .replace(/&#39;/g, "'")
        .replace(/&nbsp;/g, " ");
}

function cleanContent(content) {
    content = content.replace(/<script[^>]*>[\s\S]*?<\/script>/gi, "");
    content = content.replace(/<style[^>]*>[\s\S]*?<\/style>/gi, "");
    return content;
}

function stripTags(text) {
    return text.replace(/<[^>]+>/g, "");
}

function normalizeWhitespace(text) {
    return text.replace(/\s{2,}/g, " ").trim();
}

function extractCoverUrl(srcset) {
    // Extract the actual image URL from Next.js srcset
    // The srcset contains URLs like /_next/image?url=https%3A%2F%2F...
    if (!srcset) return "";

    // Get the first URL from srcset
    var firstUrl = srcset.split(" ")[0];
    if (!firstUrl) return "";

    // Decode the URL parameter
    var urlMatch = firstUrl.match(/url=([^&]+)/);
    if (urlMatch) {
        return decodeURIComponent(urlMatch[1]);
    }

    return firstUrl;
}
