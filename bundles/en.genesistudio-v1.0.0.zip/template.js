// Genesis Studio source implementation
// Helper functions from helpers.js are available globally
// SourceMetadata is injected from source.json

// Initialize baseUrl from injected metadata
var baseUrl = SourceMetadata.baseURL;
var apiBaseUrl = "https://api.genesistudio.com";

var NovelSource = {

    getFilters: function() {
        return {};
    },

    getPopularNovels: function(page, filters) {
        page = page || 1;
        filters = filters || {};

        log("Fetching popular novels from Genesis Studio, page: " + page);

        // Genesis Studio only has ~14 novels, no pagination needed
        if (page > 1) {
            return [];
        }

        // Use the JSON API endpoint - fields must be a JSON array
        var fields = '["id","novel_title","cover","abbreviation","author"]';
        var url = baseUrl + "/api/directus/novels?status=published&fields=" + encodeURIComponent(fields) + "&limit=-1";
        log("API URL: " + url);

        try {
            var response = fetch(url);

            if (!response) {
                log("No response object");
                return [];
            }

            if (response.error) {
                log("Response has error: " + response.error);
                return [];
            }

            if (!response.ok) {
                log("HTTP error: " + response.status);
                return [];
            }

            var data = response.json;

            if (!data || !Array.isArray(data)) {
                log("Invalid JSON response");
                return [];
            }

            var novels = [];

            for (var i = 0; i < data.length; i++) {
                var novel = data[i];

                // Build cover URL using Cloudflare CDN (handles any image format)
                var coverUrl = "";
                if (novel.cover) {
                    // Use the CDN URL which auto-detects format and converts to jpg
                    coverUrl = baseUrl + "/cdn-cgi/image/width=400,height=600,fit=cover,format=auto,quality=85/" + apiBaseUrl + "/storage/v1/object/public/directus/" + novel.cover;
                }

                novels.push({
                    novelId: novel.abbreviation || novel.id,
                    title: novel.novel_title || "",
                    coverUrl: coverUrl,
                    author: novel.author || "",
                    description: novel.author ? "by " + novel.author : ""
                });
                log("Found novel: " + novel.novel_title + " (" + novel.abbreviation + ")");
            }

            log("Found " + novels.length + " novels");
            return novels;

        } catch (e) {
            log("Exception: " + e);
            return [];
        }
    },

    searchNovels: function(query, page) {
        log("Search not supported for Genesis Studio");
        // Genesis Studio doesn't have a search feature visible
        // Return empty results
        return [];
    },

    getNovelDetails: function(novelId) {
        log("Getting details for novel: " + novelId);

        // Use the JSON API to get novel details - fields must be a JSON array
        var fields = '["id","novel_title","cover","abbreviation","author","synopsis","rating","serialization","genres"]';
        var url = baseUrl + "/api/directus/novels?status=published&fields=" + encodeURIComponent(fields) + "&limit=-1";

        try {
            var response = fetch(url);

            if (!response || response.error || !response.ok) {
                log("Error fetching novel details");
                return null;
            }

            var data = response.json;

            if (!data || !Array.isArray(data)) {
                log("Invalid JSON response");
                return null;
            }

            // Find the novel by abbreviation
            var novel = null;
            for (var i = 0; i < data.length; i++) {
                if (data[i].abbreviation === novelId) {
                    novel = data[i];
                    break;
                }
            }

            if (!novel) {
                log("Novel not found: " + novelId);
                return null;
            }

            // Build cover URL using Cloudflare CDN (handles any image format)
            var coverUrl = "";
            if (novel.cover) {
                // Use the CDN URL which auto-detects format and converts to jpg
                coverUrl = baseUrl + "/cdn-cgi/image/width=400,height=600,fit=cover,format=auto,quality=85/" + apiBaseUrl + "/storage/v1/object/public/directus/" + novel.cover;
            }

            // Parse genres - they may be a comma-separated string or array
            var genres = [];
            if (novel.genres) {
                if (typeof novel.genres === "string") {
                    genres = novel.genres.split(",").map(function(g) { return g.trim(); });
                } else if (Array.isArray(novel.genres)) {
                    genres = novel.genres;
                }
            }

            // Map serialization status
            var status = "Ongoing";
            if (novel.serialization === "completed") {
                status = "Completed";
            } else if (novel.serialization === "hiatus") {
                status = "Hiatus";
            }

            return {
                novelId: novelId,
                title: novel.novel_title || "",
                coverUrl: coverUrl,
                author: novel.author || "",
                genres: genres,
                status: status,
                rating: novel.rating ? String(novel.rating) : "5.0",
                description: novel.synopsis || ""
            };

        } catch (e) {
            log("Exception: " + e);
            return null;
        }
    },

    getChapterList: function(novelId) {
        log("Getting chapters for novel: " + novelId);

        // First, we need to get the novel's UUID from the abbreviation
        var fields = '["id","abbreviation"]';
        var novelsUrl = baseUrl + "/api/directus/novels?status=published&fields=" + encodeURIComponent(fields) + "&limit=-1";

        try {
            var novelsResponse = fetch(novelsUrl);

            if (!novelsResponse || novelsResponse.error || !novelsResponse.ok) {
                log("Error fetching novels list");
                return [];
            }

            var novelsData = novelsResponse.json;
            if (!novelsData || !Array.isArray(novelsData)) {
                log("Invalid novels JSON response");
                return [];
            }

            // Find the novel UUID by abbreviation
            var novelUuid = null;
            for (var i = 0; i < novelsData.length; i++) {
                if (novelsData[i].abbreviation === novelId) {
                    novelUuid = novelsData[i].id;
                    break;
                }
            }

            if (!novelUuid) {
                log("Novel UUID not found for: " + novelId);
                return [];
            }

            log("Found novel UUID: " + novelUuid);

            // Now fetch chapters using the UUID
            var chaptersUrl = baseUrl + "/api/novels-chapter/" + novelUuid;
            var response = fetch(chaptersUrl);

            if (!response || response.error || !response.ok) {
                log("Error fetching chapter list");
                return [];
            }

            var json = response.json;

            if (!json || !json.success || !json.data || !json.data.chapters) {
                log("Invalid chapters JSON response");
                return [];
            }

            var chapters = [];
            var chaptersData = json.data.chapters;

            for (var i = 0; i < chaptersData.length; i++) {
                var chapter = chaptersData[i];

                // Only include free chapters (isPaid === false)
                if (chapter.isPaid) {
                    continue;
                }

                // Skip unreleased chapters
                if (chapter.status !== "released") {
                    continue;
                }

                chapters.push({
                    chapterId: novelId + "/" + chapter.id,
                    title: chapter.chapter_title || ("Chapter " + chapter.chapter_number),
                    index: chapter.chapter_number - 1
                });
            }

            // Sort chapters by chapter_number (ascending order)
            chapters.sort(function(a, b) {
                return a.index - b.index;
            });

            log("Found " + chapters.length + " free chapters for " + novelId);
            return chapters;

        } catch (e) {
            log("Exception: " + e);
            return [];
        }
    },

    getChapterContent: function(chapterId) {
        log("Getting content for chapter: " + chapterId);

        var viewerId = chapterId;

        if (chapterId.indexOf("/") > -1) {
            var parts = chapterId.split("/");
            viewerId = parts[1];
        }

        // Use Supabase API with API key
        var supabaseUrl = "https://ckiwecspopkpvhccpisf.supabase.co/rest/v1/chapters";
        var supabaseKey = "sb_publishable_YwmK1j7R538L3C4E3qMw6w_au-q5prS";
        var url = supabaseUrl + "?select=id,chapter_title,chapter_number,chapter_content,status&id=eq." + viewerId + "&status=eq.released";
        log("Fetching from: " + url);

        try {
            var response = fetch(url, {
                headers: {
                    "apikey": supabaseKey,
                    "Authorization": "Bearer " + supabaseKey,
                    "Accept": "application/json"
                }
            });

            if (!response || response.error) {
                return "<p>Error loading chapter content: " + (response ? response.error : "Network error") + "</p>";
            }

            if (!response.ok) {
                return "<p>Error loading chapter content. Status: " + response.status + "</p>";
            }

            var json = response.json;

            if (!json || (Array.isArray(json) && json.length === 0)) {
                return "<p>This chapter may require a premium subscription or login to access.</p>";
            }

            // Handle both array and object responses
            var chapter = Array.isArray(json) ? json[0] : json;
            var rawContent = chapter.chapter_content;

            if (!rawContent || rawContent.trim().length < 50) {
                return "<p>This chapter may require a premium subscription or login to access.</p>";
            }

            // Split by newlines and create paragraphs
            var lines = rawContent.split(/\n/);
            var paragraphs = [];

            for (var i = 0; i < lines.length; i++) {
                var line = lines[i].trim();
                if (line.length > 0) {
                    // Handle gold-text boxes
                    if (line.indexOf('<div class="gold-text">') > -1) {
                        var goldPattern = /<div class="gold-box"><p>([^<]+)<\/p><\/div>/g;
                        var goldMatch;
                        while ((goldMatch = goldPattern.exec(line)) !== null) {
                            paragraphs.push("<p><strong>" + decodeHTML(goldMatch[1]) + "</strong></p>");
                        }
                    } else {
                        paragraphs.push("<p>" + decodeHTML(line) + "</p>");
                    }
                }
            }

            var content = paragraphs.join("\n");
            log("Successfully extracted " + paragraphs.length + " paragraphs");
            return content;

        } catch (e) {
            log("Exception: " + e);
            return "<p>Error loading chapter content.</p>";
        }
    }
};

log("Genesis Studio plugin loaded successfully");
